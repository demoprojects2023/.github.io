<?php
session_start();
unset($_SESSION['SESS_USER_TOKEN']);
unset($_SESSION['SESS_USER_NAME']);
unset($_SESSION['SESS_USER_TYPE']);
unset($_SESSION['SESS_USER_EMAIL']);
setcookie('LU001', "", -1, '/');
if (isset($_GET['updated'])) {
?>
    <script>
        window.location.href = '../login.php?updated';
    </script>
<?php
} else {
?>
    <script>
        window.location.href = '../login.php?signout';
    </script>
<?php
}
?>
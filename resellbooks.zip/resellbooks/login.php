<?php
session_start();
include('include/dbConnect.php');
include('include/helper.php');

if (isset($_SESSION['SESS_USER_TOKEN']) && (trim($_SESSION['SESS_USER_TOKEN']) != '')) {
?>
	<script>
		window.location.href = '/shop.php';
	</script>
	<?php
} else {
	if (isset($_COOKIE['LU001']) && $_COOKIE['LU001'] == true) {
		$remember_token = $_COOKIE['LU001'];
		$stmt = $db->prepare("SELECT * FROM users WHERE remember_token = ? AND status = 1 LIMIT 0,1");
		$stmt->bindParam(1, $remember_token);
		$stmt->execute();
		$usercount = $stmt->rowCount();
		if ($usercount > 0) {
			$user_rows = $stmt->fetch(PDO::FETCH_ASSOC);
			$_SESSION['SESS_USER_TOKEN'] = $user_rows['token'];
			$_SESSION['SESS_USER_NAME'] = $user_rows['name'];
			$_SESSION['SESS_USER_TYPE'] = $user_rows['user_type'];
			$_SESSION['SESS_USER_EMAIL'] = $user_rows['email'];
			$_SESSION['SESS_USER_CITY'] = $user_rows['city'];

			setcookie("LU001", $remember_token, time() + (10 * 365 * 24 * 60 * 60), '/');
	?>
			<script>
				window.location.href = window.location.origin + '/shop.php';
			</script>
<?php
		}
	}
}

$err = '';
$err2 = '';
$redirect = '../shop.php';
$otpVerification = 0;
if (isset($_GET['signout'])) {
	$err = 'Logged out successfully';
} elseif (isset($_GET['expired'])) {
	$err = 'Session expired,<br>please login again.';
}
if (isset($_GET['login'])) {
	$err2 = 'Registration successfull,<br>you can login now.';
}
if (isset($_GET['updated'])) {
	$err2 = 'Password updated,<br>please login with new password.';
}
if (isset($_POST['submit'], $_POST['email'], $_POST['password'])) {
	$remember_token = genToken();
	$email = $_POST['email'];
	$password = $_POST['password'];
	$redirect = $_POST['redirect'];

	$qryadmn = $db->prepare("SELECT * FROM users WHERE email = '$email' AND password = '$password'");
	$qryadmn->execute();
	if ($qryadmn->rowcount() > 0) {
		$rowadmn = $qryadmn->fetch();
		if ($rowadmn['status'] == 1) {
			$_SESSION['SESS_USER_TOKEN'] = $rowadmn['token'];
			$_SESSION['SESS_USER_NAME'] = $rowadmn['name'];
			$_SESSION['SESS_USER_TYPE'] = $rowadmn['user_type'];
			$_SESSION['SESS_USER_EMAIL'] = $rowadmn['email'];

			setcookie("LU001", $remember_token, time() + (10 * 365 * 24 * 60 * 60), '/');

			$db->prepare("UPDATE users SET remember_token = '$remember_token' WHERE  token = '" . $rowadmn['token'] . "'")->execute();

			header("location: $redirect");
		} else {
			$err = 'Something went wrong!<br>Contact QUICKFUEL to fix.';
		}
	} else {
		$err = 'Username or password is wrong!<br>Try Again.';
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>KITHAB MASTER</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/ionicons.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">


	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
</head>

<body class="goto-here">
	<?php require_once 'include/header.php'; ?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
		<div class="container">
			<div class="row no-gutters slider-text align-items-center justify-content-center">
				<div class="col-md-9 ftco-animate text-center">
					<h1 class="mb-0 breadd font-weight-bolder text-white">LOGIN</h1>
				</div>
			</div>
		</div>
	</div>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 ftco-animate">
					<div class="card card-rounded shadow-lg">
						<div class="card-body">
							<form action="../login.php" method="post" autocomplete="off">
								<input type="hidden" name="redirect" value="<?php echo $redirect ?>">
								<center><img src="images/logo.png" width="200"></center>
								<h2 class="mb-3 bbilling-heading font-weight-bolder text-center">LOGIN</h2>
								<?php if ($err2 != '') {
									echo '<p class="text-success w-100 text-center"><b>' . $err2 . '</b></p>';
								} ?>
								<div class="row align-items-end">
									<div class="col-md-12 border-top pt-3">
										<div class="form-group">
											<input type="email" name="email" id="username" class="form-control text-dark rounded-pill" placeholder="Registered Email">
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<input type="password" name="password" class="form-control text-dark rounded-pill" placeholder="Password">
											<a href="javascript:void(0);" onclick="forgotpwd();" class="text-right w-100 d-block mb-4">Forgot Password?</a>
										</div>
									</div>
									<?php if ($err != '') {
										echo '<p class="text-danger w-100 text-center"><b>' . $err . '</b></p>';
									} ?>
									<div class="col-md-12 border-bottom pb-3 text-center">
										<button type="submit" name="submit" class="btn btn-primary py-3 px-5">LOGIN</button>
									</div>
									<div class="col-md-12">
										<p class="text-center mt-5">Not Registered? <a href="register.php"><br>Register Now</a></p>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<hr>

	<?php require_once 'include/footer.php'; ?>
	<script src="js/jquery.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="js/main.js"></script>
	<script>
		function forgotpwd() {
			var email = $("#username").val();
			if (email == '') {
				alert("Enter your registered email Id.");
			} else {
				$.ajax({
					type: 'POST',
					url: "forgot.php?email=" + email,
					data: '',
					dataType: 'JSON',
					cache: false,
					contentType: false,
					processData: false,
					success: function(data) {
						var result = JSON.parse(JSON.stringify(data));
						console.log(result.status);
						if (result.status == 1) {
							alert("Check your email inboc for your password.");
						} else {
							alert(result.message);
						}
					},
					error: function(data) {
						console.log(data);
					}
				});
			}
		}
	</script>

</body>

</html>
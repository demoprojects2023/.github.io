<?php
session_start();
include('include/dbConnect.php');
include('include/helper.php');

if (isset($_SESSION['SESS_USER_TOKEN']) && trim($_SESSION['SESS_USER_TOKEN']) != '') {
	header("location: ../profile.php");
}
$err = '';
$err2 = '';
if (isset($_POST['submit'], $_POST['name'], $_POST['email'], $_POST['contact_no'], $_POST['city'], $_POST['password'], $_POST['user_type'])) {
	$token = genToken();
	$name = $_POST['name'];
	$email = $_POST['email'];
	$contact_no = $_POST['contact_no'];
	$city = $_POST['city'];
	$password = $_POST['password'];
	$user_type = $_POST['user_type'];

	$qryadmn = $db->prepare("SELECT * FROM users WHERE email = '$email'");
	$qryadmn->execute();

	if ($qryadmn->rowcount() > 0) {
		$err = 'Email already registered with us.';
	} else {
		$db->prepare("INSERT INTO users (token, name, email, password, contact_no, city, user_type) VALUES ('$token', '$name', '$email', '$password', '$contact_no', '$city', '$user_type')")->execute();

		$notification = 'Hi '.ucwords($name).', you have succesfully registered on Kithab Master.';
		Notify($notification, $email);
?>
		<script>
			window.location.href = '../login.php?login';
		</script>
<?php
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>KITHAB MASTER</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/ionicons.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">


	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
</head>

<body class="goto-here">
	<?php require_once 'include/header.php'; ?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
		<div class="container">
			<div class="row no-gutters slider-text align-items-center justify-content-center">
				<div class="col-md-9 ftco-animate text-center">
					<h1 class="mb-0 breadd font-weight-bolder text-white">REGISTER</h1>
				</div>
			</div>
		</div>
	</div>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 ftco-animate">
					<div class="card card-rounded shadow-lg">
						<div class="card-body">
							<form action="../register.php" method="post" autocomplete="off">
								<center><img src="images/logo.png" width="200"></center>
								<h2 class="mb-3 bbilling-heading font-weight-bolder text-center">WELCOME TO KITHAB MASTER</h2>
								<div class="row align-items-end">
									<div class="col-md-12">
										<div class="form-group">
											<select name="user_type" id="" class="form-control text-dark rounded-pill" required="">
												<option value="">Register As</option>
												<option value="buyer">Buyer</option>
												<option value="seller">Seller</option>
											</select>
										</div>
									</div>
									<div class="col-md-12 border-top pt-3">
										<div class="form-group">
											<input type="text" name="name" class="form-control text-dark rounded-pill" placeholder="Fullname" required>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<select name="city" id="" class="form-control text-dark rounded-pill" required>
												<option value="">Choose your city</option>
												<?php
												$qry_cities = $db->prepare("SELECT * FROM cities GROUP BY district ORDER BY district");
												$qry_cities->execute();
												for ($i = 1; $row_cities = $qry_cities->fetch(); $i++) {
													echo '<option value="' . strtolower($row_cities['district']) . '">' . $row_cities['district'] . ', ' . $row_cities['state'] . ', ' . $row_cities['country'] . '</option>';
												}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<input type="text" pattern="[7-9]{1}[0-9]{9}" name="contact_no" class="form-control text-dark rounded-pill" placeholder="Contact Number" required>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<input type="email" name="email" class="form-control text-dark rounded-pill" placeholder="Email ID" required>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<input type="password" name="password" class="form-control text-dark rounded-pill" placeholder="Password" required>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-12">
											<div class="checkbox">
												<label><input type="checkbox" value="" class="mr-2" required> I have read and accept the terms and conditions</label>
											</div>
										</div>
									</div>
									<?php if ($err != '') {
										echo '<p class="text-danger w-100 text-center"><b>' . $err . '</b></p>';
									} ?>
									<div class="col-md-12 border-bottom pb-3 text-center">
										<button type="submit" name="submit" class="btn btn-primary py-3 px-5">REGISTER</button>
									</div>
									<div class="col-md-12">
										<p class="text-center mt-5">Already Registered? <a href="login.php"><br>Login Now</a></p>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<hr>
	<?php require_once 'include/footer.php'; ?>
	<script src="js/jquery.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
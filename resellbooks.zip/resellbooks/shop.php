<?php
include('include/auth-all.php');
include('include/dbConnect.php');
include('include/helper.php');

if ($_SESSION['SESS_USER_TYPE'] != 'buyer') {
	header("location:books.php?status=1");
}

$qry_user = $db->prepare("SELECT * FROM users WHERE token = '$user'");
$qry_user->execute();
$row_user = $qry_user->fetch();
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>KITHAB MASTER</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/ionicons.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">


	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
</head>

<body class="goto-here">
	<?php require_once 'include/header.php'; ?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
		<div class="container">
			<div class="row no-gutters slider-text align-items-center justify-content-center">
				<div class="col-md-9 ftco-animate text-center">
					<h1 class="mb-0 breadd font-weight-bolder text-white">SHOP NOW</h1>
				</div>
			</div>
		</div>
	</div>
	<section class="ftco-section bg-light">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h2 class="mb-4">Books available at: <?php echo ucwords($row_user['city']) ?>, Kerala, India </h2>
					<div class="row">
						<?php
						$qry = "SELECT * FROM books WHERE status = 1 AND stock > 0 AND city = '" . $row_user['city'] . "' ORDER BY id DESC";
						$qry_book = $db->prepare($qry);
						$qry_book->execute();
						if ($qry_book->rowcount() > 0) {
							for ($i = 1; $row_book = $qry_book->fetch(); $i++) {
								$status = $row_book['status'];
								$link = "book-details.php?token=" . $row_book['token'];
						?>
								<div class="col-sm-6 col-md-6 col-lg-3 ftco-animate">
									<div class="product">
										<a href="<?php echo $link ?>" class="img-prod"><img class="img-fluid" src="<?php echo $row_book['image'] ?>" alt="Colorlib Template">
											<div class="overlay"></div>
										</a>
										<div class="text py-2 px-0">
											<h3 class="font-weight-bolder text-truncate"><a href="<?php echo $link ?>"><?php echo strtoupper($row_book['title']) ?></a></h3>
											<p class="font-weight-bolder text-dark text-truncate">By <?php echo strtoupper($row_book['author']) ?></p>
											<p class="d-inline-block border px-2 py-1 bg-dark text-white rounded-pill small">YEAR: <?php echo strtoupper($row_book['year']) ?></p>
											<p class="d-inline-block border px-2 py-1 bg-dark text-white rounded-pill small"><?php echo strtoupper($row_book['category']) ?></p>
											<div class="d-flex">
												<div class="pricing w-100">
													<p class="price">
														<span class="mr-1 price-dc text-danger font-weight-bolder">INR&nbsp;<?php echo number_format($row_book['mrp'], 2) ?></span>
														<span class="price-sale text-success font-weight-bolder">INR&nbsp;<?php echo number_format($row_book['rate'], 2) ?></span>
													</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php }
						} else { ?>
							<div class="ftco-animate col-12 mt-5 mb-5 pt-5 pb-5">
								<h1 class="text-center text-muted mt-5 mb-5">
									No books found at your location
								</h1>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<hr>

	<?php require_once 'include/footer.php'; ?>



	<script src="js/jquery.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
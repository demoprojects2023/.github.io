<?php
include('include/auth-all.php');
include('include/dbConnect.php');
include('include/helper.php');
$qry_cart = $db->prepare("SELECT * FROM cart WHERE cart_by = '$user'");
$qry_cart->execute();
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>KITHAB MASTER</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/ionicons.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">


	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
</head>

<body class="goto-here">
	<?php require_once 'include/header.php'; ?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
		<div class="container">
			<div class="row no-gutters slider-text align-items-center justify-content-center">
				<div class="col-md-9 ftco-animate text-center">
					<h1 class="mb-0 breadd font-weight-bolder text-white">MY BOOKS</h1>
				</div>
			</div>
		</div>
	</div>
	<section class="ftco-section ftco-cart">
		<div class="container">
			<?php
			if ($qry_cart->rowcount() > 0) {
				$row_cart = $qry_cart->fetch();
				$book = $row_cart['book'];
				$qry = "SELECT * FROM books WHERE token = '$book' AND approved = 1 AND status = 1 AND stock > 0";
				$qry_book = $db->prepare($qry);
				$qry_book->execute();
				if ($qry_book->rowcount() == 0) {
					$db->prepare("DELETE FROM cart WHERE cart_by = '$user'")->execute();
			?>
					<script>
						window.location.replace("cart.php");
					</script>
				<?php
					exit();
				}
				$row_book = $qry_book->fetch();
				?>
				<div class="row">
					<div class="col-md-12 ftco-animate">
						<div class="cart-list">
							<table class="table">
								<thead class="thead-primary">
									<tr class="text-center">
										<th>&nbsp;</th>
										<th>&nbsp;</th>
										<th>Product</th>
										<th>Price</th>
										<th>Quantity</th>
										<th>Total</th>
									</tr>
								</thead>
								<tbody>
									<tr class="text-center">
										<td class="product-remove"><a href="actions/empty-cart.php"><span class="ion-ios-close"></span></a></td>

										<td class="image-prod">
											<div class="img" style="background-image:url(<?php echo $row_book['image'] ?>);"></div>
										</td>

										<td class="product-name">
											<h3><?php echo strtoupper($row_book['title']) ?></h3>
											<p>Far far away, behind the word mountains, far from the countries</p>
										</td>

										<td class="price">INR <?php echo number_format($row_book['rate'], 2) ?></td>

										<td class="quantity">
											1
										</td>

										<td class="total">INR <?php echo number_format($row_book['rate'], 2) ?></td>
									</tr><!-- END TR-->

								</tbody>
							</table>
						</div>
					</div>
				</div>
				<div class="row justify-content-center">
					<div class="col col-lg-5 col-md-6 mt-5 cart-wrap ftco-animate">
						<div class="cart-total mb-3">
							<h3>Cart Totals</h3>
							<p class="d-flex">
								<span>Subtotal</span>
								<span>INR <?php echo number_format($row_book['rate'], 2) ?></span>
							</p>
							<p class="d-flex">
								<span>Delivery</span>
								<span>INR 0.00</span>
							</p>
							<p class="d-flex">
								<span>Discount</span>
								<span>INR 0.00</span>
							</p>
							<hr>
							<p class="d-flex total-price">
								<span>Total</span>
								<span>INR <?php echo number_format($row_book['rate'], 2) ?></span>
							</p>
						</div>
						<p class="text-center"><a href="checkout.php" class="btn btn-primary py-3 px-4 text-uppercase">Proceed to Checkout</a></p>
					</div>
				</div>
			<?php } else { ?>
				<div class="ftco-animate col-12 mt-5 mb-5 pt-5 pb-5">
					<h1 class="text-center text-muted mt-5 mb-5">
						You cart is empty<br>
						<a href="shop.php">Shop</a>
					</h1>
				</div>
			<?php } ?>
		</div>
	</section>
	<hr>

	<?php require_once 'include/footer.php'; ?>



	<script src="js/jquery.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
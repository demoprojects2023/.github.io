<?php
include('include/auth-all.php');
include('include/dbConnect.php');
include('include/helper.php');
$action = 1;

$qry_user = $db->prepare("SELECT * FROM users WHERE user_type = 'admin'");
$qry_user->execute();
$row_user = $qry_user->fetch();
$admin_token = $row_user['token'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>KITHAB MASTER</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

  <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
  <link rel="stylesheet" href="css/animate.css">

  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">

  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/ionicons.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">
  <link rel="stylesheet" href="css/jquery.timepicker.css">


  <link rel="stylesheet" href="css/flaticon.css">
  <link rel="stylesheet" href="css/icomoon.css">
  <link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
</head>

<body class="goto-here">
  <?php require_once 'include/header.php'; ?>
  <div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
    <div class="container">
      <div class="row no-gutters slider-text align-items-center justify-content-center">
        <div class="col-md-9 ftco-animate text-center">
          <h1 class="mb-0 breadd font-weight-bolder text-white">CHAT WITH KITHAB MASTER</h1>
        </div>
      </div>
    </div>
  </div>
  <section class="ftco-section">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10 ftco-animate">
          <div class="card card-rounded shadow-lg">
            <div class="card-header">
              <a href="profile.php" class="btn btn-dark mb-0 px-3">GO BACK</a>
            </div>
            <div class="card-body" id="scroll-to-bottom" style="min-height: 60vh;max-height: 60vh;overflow:auto;">
              <span id="LoadMessages">
                <span id="messages" class="d-block">
                </span>
              </span>
            </div>
            <div class="card-footer">
              <div class="form-group mb-0">
                <div class="input-group m-0">
                  <input type="text" class="form-control message-input" placeholder="enter you message" aria-describedby="basic-addon2">
                  <div class="input-group-append">
                    <button class="btn btn-outline-success px-5" type="button" onclick="newMessage()">Send</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <hr>
  <input type="hidden" id="LastCount" value="0">
  <input type="hidden" id="cuRrSec" value="<?php echo $admin_token ?>">

  <?php require_once 'include/footer.php'; ?>



  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="js/main.js"></script>
  <script>
    $(document).ready(function() {
      let scroll_to_bottom = document.getElementById('scroll-to-bottom');
      scroll_to_bottom.scrollTop = scroll_to_bottom.scrollHeight;
    });

    function newMessage() {
      var message = $(".message-input").val();
      if ($.trim(message) != '') {
        var msg = $.trim(message);
        var token = $("#cuRrSec").val();
        $.ajax({
          type: 'POST',
          url: 'actions/new-message.php',
          data: "msg=" + msg + "&token=" + token,
          success: function(r) {
            $('.message-input').val(null);
          }
        });
      }
    };

    $(window).on('keydown', function(e) {
      if (e.which == 13) {
        newMessage();
        return false;
      }
    });

    setInterval(function() {
      LoadMessagesappendTo();
    }, 1200);

    function LoadMessagesappendTo() {
      var chatWith = $("#cuRrSec").val();
      var LastCount = $("#LastCount").val();
      var chatWithdp = '';
      $.ajax({
        type: 'POST',
        url: 'actions/messagesappendTo.php',
        data: "chatWith=" + chatWith + "&LastCount=" + LastCount + "&chatWithdp=" + chatWithdp,
        success: function(r) {
          $("#messages").html(r);
          var isHovered = $('#LoadMessages').is(":hover");
          var isfocused = $('#LoadMessages').is(":focus");
          if (isHovered == false && isfocused == false) {
            var LastCount = $("#LastCount").val();
            let scroll_to_bottom = document.getElementById('scroll-to-bottom');
            scroll_to_bottom.scrollTop = scroll_to_bottom.scrollHeight;
          }
        }
      });
    }
  </script>

</body>

</html>
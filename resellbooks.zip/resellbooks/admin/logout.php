<?php
session_start();
unset($_SESSION['SESS_ADMIN_TOKEN']);
unset($_SESSION['SESS_ADMIN_NAME']);
unset($_SESSION['SESS_ADMIN_TYPE']);
unset($_SESSION['SESS_ADMIN_EMAIL']);
setcookie('LU001', "", -1, '/');
if (isset($_GET['updated'])) {
?>
    <script>
        window.location.href = '../admin/?updated';
    </script>
<?php
} else {
?>
    <script>
        window.location.href = '../admin/?signout';
    </script>
<?php
}
?>
<?php
include('include/auth-all.php');
include('../include/dbConnect.php');
include('../include/helper.php');
$err2 = '';
if (isset($_GET['err2'])) {
    $err2 = trim($_GET['err2']);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>KITHAB MASTER</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

	<base href="<?php echo $base_url ?>" />
	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/ionicons.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">


	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
	<link rel="stylesheet" type="text/css" href="DataTable/datatables.min.css" />
	<script src="js/jquery.min.js"></script>
</head>

<body class="goto-here">
	<?php require_once 'include/header.php'; ?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
		<div class="container">
			<div class="row no-gutters slider-text align-items-center justify-content-center">
				<div class="col-md-9 ftco-animate text-center">
					<h1 class="mb-0 breadd font-weight-bolder text-white">UPDATE PASSWORD</h1>
				</div>
			</div>
		</div>
	</div>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 ftco-animate">
					<div class="card card-rounded shadow-lg">
						<div class="card-body">
                            <form action="admin/actions/update-password.php" method="post" autocomplete="off">
								<input type="hidden" name="redirect" value="<?php echo $redirect ?>">
								<h2 class="mb-3 bbilling-heading font-weight-bolder text-center">UPDATE PASSWORD</h2>
								<div class="row align-items-end">
									<div class="col-md-12 border-top pt-3">
										<div class="form-group">
											<label class="mb-0 ml-4">Current password</label>
											<input class="form-control text-dark rounded-pill" name="cPassword" type="password" placeholder="" required>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<label class="mb-0 ml-4">New password</label>
											<input class="form-control text-dark rounded-pill" name="nPassword" type="password" placeholder="" required>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<label class="mb-0 ml-4">Repeat New password</label>
											<input class="form-control text-dark rounded-pill" name="rPassword" type="password" placeholder="" required>
										</div>
									</div>
									<?php if ($err2 != '') {
										echo '<p class="text-danger w-100 text-center"><b>' . $err2 . '</b></p>';
									} ?>
									<div class="col-md-12 border-bottom pb-3 text-center">
										<a href="../admin/dashboard.php" class="btn btn-danger py-3 px-5">CANCEL</a>
										<button type="submit" name="submit" class="btn btn-primary py-3 px-5">UPDATE</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<script type="text/javascript" src="DataTable/datatables.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="js/main.js"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		});
	</script>
</body>

</html>
<?php
include('include/auth-all.php');
include('../include/dbConnect.php');
include('../include/helper.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>KITHAB MASTER</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

	<base href="<?php echo $base_url ?>" />
	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/ionicons.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">


	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
	<link rel="stylesheet" type="text/css" href="DataTable/datatables.min.css" />
	<script src="js/jquery.min.js"></script>
</head>

<body class="goto-here">
	<?php require_once 'include/header.php'; ?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
		<div class="container">
			<div class="row no-gutters slider-text align-items-center justify-content-center">
				<div class="col-md-9 ftco-animate text-center">
					<h1 class="mb-0 breadd font-weight-bolder text-white">SELLERS</h1>
				</div>
			</div>
		</div>
	</div>
	<div class="container pt-5 pb-5">
		<div class="political-header-bottom m-top-02">
			<div class="card">
				<div class="card-body">
					<div class="table-responsive">
						<table id="example" class="table table-striped table-bordered" style="width:100%">
							<thead>
								<tr>
									<th>Name</th>
									<th>Contacts</th>
									<th>City</th>
									<th>Status</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$qry = "SELECT * FROM users WHERE user_type = 'seller' ORDER BY name DESC";
								$qry_sellers = $db->prepare($qry);
								$qry_sellers->execute();
								for ($i = 1; $row_sellers = $qry_sellers->fetch(); $i++) {
									$status = $row_sellers['status'];
								?>
									<tr>
										<td><?php echo ucwords($row_sellers['name']) ?></td>
										<td><?php echo ($row_sellers['contact_no'] . '<br>' . $row_sellers['email']) ?></td>
										<td><?php echo ucwords($row_sellers['city']) ?></td>
										<td>
											<?php if ($status == 1) { ?>
												<span class="btn btn-sm btn-success">ACTIVE</span>
											<?php } else { ?>
												<span class="btn btn-sm btn-danger">HIDDEN</span>
											<?php } ?>
										</td>
										<td>
											<?php if ($status == 1) { ?>
												<a href="admin/actions/seller-status.php?status=0&token=<?php echo $row_sellers['token'] ?>" class="btn btn-sm btn-danger">BLOCK</a>
											<?php } else { ?>
												<a href="admin/actions/seller-status.php?status=1&token=<?php echo $row_sellers['token'] ?>" class="btn btn-sm btn-success">UNBLOCK</a>
											<?php } ?>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="DataTable/datatables.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="js/main.js"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		});
	</script>
</body>

</html>
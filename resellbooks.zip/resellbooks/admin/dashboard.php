<?php
include('include/auth-all.php');
include('../include/dbConnect.php');
include('../include/helper.php');

$qry = $db->prepare("SELECT * FROM categories");
$qry->execute();
$categories = $qry->rowcount();

$qry = $db->prepare("SELECT * FROM users WHERE user_type = 'seller'");
$qry->execute();
$seller = $qry->rowcount();

$qry = $db->prepare("SELECT * FROM users WHERE user_type = 'buyer'");
$qry->execute();
$buyer = $qry->rowcount();

$qry = $db->prepare("SELECT * FROM feedbacks WHERE reply IS NOT NULL");
$qry->execute();
$feedback1 = $qry->rowcount();

$qry = $db->prepare("SELECT * FROM feedbacks WHERE reply IS NULL");
$qry->execute();
$feedback0 = $qry->rowcount();

$qry = $db->prepare("SELECT * FROM books WHERE approved = 0");
$qry->execute();
$books0 = $qry->rowcount();

$qry = $db->prepare("SELECT * FROM books WHERE approved = 1");
$qry->execute();
$books1 = $qry->rowcount();

$qry = $db->prepare("SELECT * FROM chat_messages WHERE msg_read = 0 AND sender_token != '$user' GROUP BY chat_with");
$qry->execute();
$msg_read = $qry->rowcount();
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>KITHAB MASTER</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

	<base href="<?php echo $base_url ?>" />
	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/ionicons.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">


	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
</head>

<body class="goto-here">
	<?php require_once 'include/header.php'; ?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
		<div class="container">
			<div class="row no-gutters slider-text align-items-center justify-content-center">
				<div class="col-md-9 ftco-animate text-center">
					<h1 class="mb-0 breadd font-weight-bolder text-white">DASHBOARD</h1>
				</div>
			</div>
		</div>
	</div>
	<div class="grey-bg container">
		<section id="minimal-statistics">
			<div class="row mt-5 pt-5 pb-5 mb-5">
				<div class="dashCard mb-4 mr-4">
					<a href="admin/categories.php" class="card shadow-lg card-rounded">
						<div class="card-content">
							<div class="card-body">
								<div class="media d-flex">
									<div class="media-body text-left">
										<h3 class="mb-0"><?php echo $categories ?></h3>
										<h4 class="mb-0 text-danger">Categories</h4>
									</div>
								</div>
							</div>
						</div>
					</a>
				</div>
				<div class="dashCard mb-4 mr-4">
					<a href="admin/sellers.php" class="card shadow-lg card-rounded">
						<div class="card-content">
							<div class="card-body">
								<div class="media d-flex">
									<div class="media-body text-left">
										<h3 class="mb-0"><?php echo $seller ?></h3>
										<h4 class="mb-0 text-danger">Sellers</h4>
									</div>
								</div>
							</div>
						</div>
					</a>
				</div>
				<div class="dashCard mb-4 mr-4">
					<a href="admin/books.php?status=0" class="card shadow-lg card-rounded">
						<div class="card-content">
							<div class="card-body">
								<div class="media d-flex">
									<div class="media-body text-left">
										<h3 class="mb-0"><?php echo $books0 ?></h3>
										<h4 class="mb-0 text-danger">Books - To Approve</h4>
									</div>
								</div>
							</div>
						</div>
					</a>
				</div>
				<div class="dashCard mb-4 mr-4">
					<a href="admin/books.php?status=1" class="card shadow-lg card-rounded">
						<div class="card-content">
							<div class="card-body">
								<div class="media d-flex">
									<div class="media-body text-left">
										<h3 class="mb-0"><?php echo $books1 ?></h3>
										<h4 class="mb-0 text-danger">Books - Approved</h4>
									</div>
								</div>
							</div>
						</div>
					</a>
				</div>
				<div class="dashCard mb-4 mr-4">
					<a href="admin/buyers.php" class="card shadow-lg card-rounded">
						<div class="card-content">
							<div class="card-body">
								<div class="media d-flex">
									<div class="media-body text-left">
										<h3 class="mb-0"><?php echo $buyer ?></h3>
										<h4 class="mb-0 text-danger">Buyers</h4>
									</div>
								</div>
							</div>
						</div>
					</a>
				</div>
				<div class="dashCard mb-4 mr-4">
					<a href="admin/chats.php" class="card shadow-lg card-rounded">
						<div class="card-content">
							<div class="card-body">
								<div class="media d-flex">
									<div class="media-body text-left">
										<h3 class="mb-0"><?php echo $msg_read ?> Unread</h3>
										<h4 class="mb-0 text-danger">Messages</h4>
									</div>
								</div>
							</div>
						</div>
					</a>
				</div>
				<div class="dashCard mb-4 mr-4">
					<a href="admin/feedbacks.php?status=0" class="card shadow-lg card-rounded">
						<div class="card-content">
							<div class="card-body">
								<div class="media d-flex">
									<div class="media-body text-left">
										<h3 class="mb-0"><?php echo $feedback0 ?></h3>
										<h4 class="mb-0 text-danger">Feedbacks - Awaiting reply</h4>
									</div>
								</div>
							</div>
						</div>
					</a>
				</div>
				<div class="dashCard mb-4 mr-4">
					<a href="admin/feedbacks.php?status=1" class="card shadow-lg card-rounded">
						<div class="card-content">
							<div class="card-body">
								<div class="media d-flex">
									<div class="media-body text-left">
										<h3 class="mb-0"><?php echo $feedback1 ?></h3>
										<h4 class="mb-0 text-danger">Feedbacks - Replied</h4>
									</div>
								</div>
							</div>
						</div>
					</a>
				</div>
				<div class="dashCard mb-4 mr-4">
					<a href="admin/password.php" class="card shadow-lg card-rounded">
						<div class="card-content">
							<div class="card-body">
								<div class="media d-flex">
									<div class="media-body text-left">
										<h3 class="mb-0">*****</h3>
										<h4 class="mb-0 text-danger">Update Password</h4>
									</div>
								</div>
							</div>
						</div>
					</a>
				</div>
			</div>
		</section>
	</div>
	<script src="js/jquery.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
<?php
session_start();
if (!isset($_SESSION['SESS_ADMIN_TOKEN']) || trim($_SESSION['SESS_ADMIN_TOKEN']) == '') {
    header("location: ../login.php?expired");
}
$user = trim($_SESSION['SESS_ADMIN_TOKEN']);

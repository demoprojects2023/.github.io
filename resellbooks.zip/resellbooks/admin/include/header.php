<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	<div class="container">
		<a class="navbar-brand" href="admin/">
		<img src="images/logo.png" width="50" class="mr-2">
		<span class="d-none d-md-inline-block">KITHAB MASTER</span>
		</a>
		<?php if (isset($_SESSION['SESS_ADMIN_TOKEN']) && (trim($_SESSION['SESS_ADMIN_TOKEN']) != '')) { ?>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="oi oi-menu"></span> Menu
			</button>
			<div class="collapse navbar-collapse" id="ftco-nav">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item"><a href="../admin/dashboard.php" class="nav-link">Dashboard</a></li>
					<li class="nav-item"><a href="../admin/logout.php" class="nav-link">Logout</a></li>
				</ul>
			</div>
		<?php } ?>
	</div>
</nav>
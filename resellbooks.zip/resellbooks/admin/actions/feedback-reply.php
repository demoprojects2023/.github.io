<?php
session_start();
include('../../include/dbConnect.php');
include('../../include/helper.php');

$user = trim($_SESSION['SESS_USER_TOKEN']);
$reply = $_POST['reply'];
$token = $_POST['token'];

$db->prepare("UPDATE feedbacks SET reply = '$reply' WHERE token = '$token'")->execute();

header("location:../feedbacks.php?status=1");

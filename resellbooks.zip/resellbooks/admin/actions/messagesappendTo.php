<?php
session_start();
include('../../include/dbConnect.php');
include('../../include/helper.php');
$chat_with = $_POST['chatWith'];
$LastCount = $_POST['LastCount'];

$qry_chat_messages = $db->prepare("SELECT * FROM chat_messages WHERE chat_with = '$chat_with' AND id > '$LastCount'");
$qry_chat_messages->execute();
if ($qry_chat_messages->rowcount() > 0) {
    for ($i = 0; $rows_chat_messages = $qry_chat_messages->fetch(); $i++) {
        $row_id = $rows_chat_messages['id'];
        if (trim($_SESSION['SESS_ADMIN_TOKEN']) != $rows_chat_messages['sender_token']) {
            $db->prepare("UPDATE chat_messages SET msg_read = 1 WHERE id = '$row_id'")->execute();
        }
        if ($rows_chat_messages['sender_token'] == $chat_with) {

            $qry_user = $db->prepare("SELECT * FROM users WHERE token = '$chat_with'");
            $qry_user->execute();
            $row_user = $qry_user->fetch();
            
?>
            <!-- chat with -->
            <div class="clearfix"></div>
            <div class="d-inline-block bg-dark mb-1 px-3 py-1 text-white rounded-pill" style="max-width: 50%;min-width:100px;border-radius:1rem 1rem 1rem 0 !important;">
                <p class="text-white mb-0 border-bottom mb-2 d-inline"><?php echo ucwords($row_user['name']) . " (" . ucwords($row_user['user_type']) . ")"; ?></p>
                <div class="clearfix"></div>
                <?php echo $rows_chat_messages['message']; ?>
                <small class="d-block text-white-50 mb-1 text-right"><?php echo date_format_local($rows_chat_messages['created_at'], 'd M Y h:i A') ?></small>
            <?php //echo $rows_chat_messages['msg_read'] ?>
            </div>
            <div class="clearfix"></div>
        <?php
        } else {
        ?>
            <!-- me -->
            <div class="clearfix"></div>
            <div class="d-inline-block bg-dark mb-1 px-3 py-1 text-white rounded-pill float-right" style="max-width: 50%;min-width:100px;border-radius:1rem 1rem 0 1rem !important;">
                <?php echo $rows_chat_messages['message']; ?>
                <small class="d-block text-white-50 mb-1 text-right"><?php echo date_format_local($rows_chat_messages['created_at'], 'd M Y h:i A') ?></small>
            <?php //echo $rows_chat_messages['msg_read'] ?>
            </div>
            <div class="clearfix"></div>
<?php
        }
    }
}

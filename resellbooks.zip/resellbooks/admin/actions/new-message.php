<?php
session_start();
include('../../include/dbConnect.php');
include('../../include/helper.php');

$chat_with = $_POST['token'];
$sender_token = trim($_SESSION['SESS_ADMIN_TOKEN']);
$message = $_POST['msg'];

$stmt = $db->prepare("INSERT INTO chat_messages(chat_with, sender_token, message, created_at) VALUES (?, ?, ?, ?)");
$stmt->bindParam(1, $chat_with);
$stmt->bindParam(2, $sender_token);
$stmt->bindParam(3, $message);
$stmt->bindParam(4, $current_date_time_local);
$stmt->execute();
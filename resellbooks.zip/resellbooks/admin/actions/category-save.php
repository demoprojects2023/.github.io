<?php
session_start();
include('../../include/dbConnect.php');
include('../../include/helper.php');
$token = genToken();
$name = $_POST['name'];
$created_at = $current_date_time_local;

$stmt = $db->prepare("INSERT INTO categories(token, name, created_at) VALUES (?, ?, ?)");
$stmt->bindParam(1, $token);
$stmt->bindParam(2, $name);
$stmt->bindParam(3, $created_at);
$stmt->execute();

header("location:../categories.php");

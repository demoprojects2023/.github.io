<?php
session_start();
include('../../include/dbConnect.php');
include('../../include/helper.php');
$token = $_SESSION['SESS_ADMIN_TOKEN'];
$red = "../dashboard.php";

if (isset($_POST['cPassword'], $_POST['nPassword'], $_POST['rPassword'])) {
    $stmt = $db->prepare("SELECT * FROM users WHERE token = ? LIMIT 0,1");
    $stmt->bindParam(1, $token);
    $stmt->execute();
    $usercount = $stmt->rowCount();
    if ($usercount > 0) {
        $user_rows = $stmt->fetch(PDO::FETCH_ASSOC);
        if (trim($_POST['cPassword']) == $user_rows['password']) {
            if (trim($_POST['nPassword']) == trim($_POST['rPassword'])) {
                $nPassword = trim($_POST['nPassword']);
                $updateData = $db->prepare("UPDATE users SET password = :password WHERE token = :token");
                $updateData->bindParam(':password', $nPassword, PDO::PARAM_STR);
                $updateData->bindParam(':token', $token, PDO::PARAM_STR);
                $updateData->execute();
                $err = 'Password Updated.';
                $red = "../logout.php?updated";
            } else {
                $err = 'Repeat password is not matching.';
                $red = "../password.php?err2=" . $err;
            }
        } else {
            $err = 'Current password is wrong.';
            $red = "../password.php?err2=" . $err;
        }
    } else {
        $err = 'Somehting went wrong wrong.';
        $red = "../password.php?err2=" . $err;
    }
}

header("location:" . $red . "");

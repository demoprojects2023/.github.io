<?php
session_start();
include('../../include/dbConnect.php');
include('../../include/helper.php');
$token = $_GET['token'];

$db->prepare("UPDATE books SET status = 1, approved = 1, approved_on = '$current_date_time_local' WHERE token = '$token'")->execute();

header("location:../book-details.php?token=" . $token . "");
<?php
session_start();
include('../../include/dbConnect.php');
include('../../include/helper.php');
$message = '';
if (isset($_FILES['upload-Image']) && $_FILES['upload-Image']['name'] != "") {
    $target_dir = "../../images/books/";
    $fileName =  genToken();
    $savePath = "images/books/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    $target_file = $target_dir . basename($_FILES["upload-Image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $target_file = $target_dir . $fileName . '.' . $imageFileType;
    $savePath = $savePath . $fileName . '.' . $imageFileType;

    $uploadOk = 1;

    // Check if image file is a actual image or fake image
    if (isset($_POST["submit"])) {
        $check = getimagesize($_FILES["upload-Image"]["tmp_name"]);
        if ($check !== false) {
            $message = "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            $message = "File is not an image.";
            $uploadOk = 0;
        }
    }

    // Check if file already exists
    if (file_exists($target_file)) {
        $message = "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["upload-Image"]["size"] > 1500000) {
        $message = "Sorry, your file is too large (max size 1.5MB).";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if (
        $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif"
    ) {
        $message = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        $message .= " Your file was not uploaded.";
        // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["upload-Image"]["tmp_name"], $target_file)) {
            $uploadOk = 1;
            $message = "The file has been uploaded.";
        } else {
            $uploadOk = 0;
            $message = "Sorry, there was an error uploading your file.";
        }
    }
    if ($uploadOk == 1) {
        $token = $_POST['token'];
        $title = $_POST['title'];
        $category = $_POST['category'];
        $year = $_POST['year'];
        $mrp = $_POST['mrp'];
        $rate = $_POST['rate'];
        $stock = $_POST['stock'];
        $city = $_POST['city'];
        $about = $_POST['about'];
        $act_stock = $_POST['stock'];
        $created_at = $current_date_time_local;
        $edited = 1;
        $approved = 1;
        $status = 1;

        $updateData = $db->prepare("UPDATE books SET category = :category, year = :year, mrp = :mrp, rate = :rate, stock = :stock, city = :city, about = :about, image = :image, title = :title, act_stock = :act_stock, edited = :edited, approved = :approved, status = :status WHERE token = :token");
        $updateData->bindParam(':category', $category, PDO::PARAM_STR);
        $updateData->bindParam(':year', $year, PDO::PARAM_STR);
        $updateData->bindParam(':mrp', $mrp, PDO::PARAM_STR);
        $updateData->bindParam(':rate', $rate, PDO::PARAM_STR);
        $updateData->bindParam(':stock', $stock, PDO::PARAM_STR);
        $updateData->bindParam(':city', $city, PDO::PARAM_STR);
        $updateData->bindParam(':about', $about, PDO::PARAM_STR);
        $updateData->bindParam(':image', $savePath, PDO::PARAM_STR);
        $updateData->bindParam(':title', $title, PDO::PARAM_STR);
        $updateData->bindParam(':act_stock', $act_stock, PDO::PARAM_STR);
        $updateData->bindParam(':edited', $edited, PDO::PARAM_STR);
        $updateData->bindParam(':approved', $approved, PDO::PARAM_STR);
        $updateData->bindParam(':status', $status, PDO::PARAM_STR);
        $updateData->bindParam(':token', $token, PDO::PARAM_STR);
        $updateData->execute();
    }
} else {
    $uploadOk = 1;
    $token = $_POST['token'];
    $title = $_POST['title'];
    $category = $_POST['category'];
    $year = $_POST['year'];
    $mrp = $_POST['mrp'];
    $rate = $_POST['rate'];
    $stock = $_POST['stock'];
    $city = $_POST['city'];
    $about = $_POST['about'];
    $act_stock = $_POST['stock'];
    $created_at = $current_date_time_local;
    $edited = 1;
    $approved = 1;
    $status = 1;

    $updateData = $db->prepare("UPDATE books SET category = :category, year = :year, mrp = :mrp, rate = :rate, stock = :stock, city = :city, about = :about, title = :title, act_stock = :act_stock, edited = :edited, approved = :approved, status = :status WHERE token = :token");
    $updateData->bindParam(':category', $category, PDO::PARAM_STR);
    $updateData->bindParam(':year', $year, PDO::PARAM_STR);
    $updateData->bindParam(':mrp', $mrp, PDO::PARAM_STR);
    $updateData->bindParam(':rate', $rate, PDO::PARAM_STR);
    $updateData->bindParam(':stock', $stock, PDO::PARAM_STR);
    $updateData->bindParam(':city', $city, PDO::PARAM_STR);
    $updateData->bindParam(':about', $about, PDO::PARAM_STR);
    $updateData->bindParam(':title', $title, PDO::PARAM_STR);
    $updateData->bindParam(':act_stock', $act_stock, PDO::PARAM_STR);
    $updateData->bindParam(':edited', $edited, PDO::PARAM_STR);
    $updateData->bindParam(':approved', $approved, PDO::PARAM_STR);
    $updateData->bindParam(':status', $status, PDO::PARAM_STR);
    $updateData->bindParam(':token', $token, PDO::PARAM_STR);
    $updateData->execute();
}
echo json_encode(array(
    "status" => $uploadOk,
    "message" => $message
));
exit();

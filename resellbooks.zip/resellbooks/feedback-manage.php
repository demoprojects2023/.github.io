<?php
include('include/auth-all.php');
include('include/dbConnect.php');
include('include/helper.php');
$action = 1;
$heading = 'Send Feedback';
if (isset($_GET['token'])) {
  $token = $_GET['token'];
  $qry_feedbacks = $db->prepare("SELECT * FROM feedbacks WHERE token = '$token'");
  $qry_feedbacks->execute();
  if ($qry_feedbacks->rowcount() > 0) {
    $action = 2;
    $row_feedbacks = $qry_feedbacks->fetch();
    $heading = 'Edit Feedback';
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>KITHAB MASTER</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

  <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
  <link rel="stylesheet" href="css/animate.css">

  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">

  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/ionicons.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">
  <link rel="stylesheet" href="css/jquery.timepicker.css">


  <link rel="stylesheet" href="css/flaticon.css">
  <link rel="stylesheet" href="css/icomoon.css">
  <link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
</head>

<body class="goto-here">
  <?php require_once 'include/header.php'; ?>
  <div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
    <div class="container">
      <div class="row no-gutters slider-text align-items-center justify-content-center">
        <div class="col-md-9 ftco-animate text-center">
          <h1 class="mb-0 breadd font-weight-bolder text-white">FEEDBACKS</h1>
        </div>
      </div>
    </div>
  </div>
  <section class="ftco-section">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-6 ftco-animate">
          <div class="card card-rounded shadow-lg">
            <div class="card-header">
              <a href="feedbacks.php" class="btn btn-dark mb-0 px-3">GO BACK</a>
            </div>
            <div class="card-body">
              <?php if ($action == 1) {
              ?>
                <form class="mt-3" action="actions/feedback-save.php" method="post" autocomplete="off" enctype="multipart/form-data">
                  <div class="contact-form">
                    <div class="form-group">
                      <input type="text" class="form-control rounded-pill" placeholder=" subject" name="subject" required>
                    </div>
                    <div class="form-group">
                      <input type="file" class="form-control rounded-pill" name="photo" placeholder="image" accept="image/*">
                    </div>
                    <div class="form-group">
                      <textarea class="form-control rounded-pill" placeholder=" your feedback or complaint" rows="10" style="resize: none;" name="feedback" required></textarea>
                    </div>
                    <div>
                      <center>
                        <button type="submit" name="submit" class="btn btn-primary py-3 px-5">
                          Send Feedback
                        </button>
                      </center>
                    </div>
                  </div>
                </form>
              <?php
              } else {
              ?>
                <form class="mt-3" action="actions/feedback-update.php" method="post" autocomplete="off" enctype="multipart/form-data">
                  <div class="contact-form">
                    <input type="hidden" name="token" value="<?php echo $row_feedbacks['token'] ?>">
                    <div class="form-group">
                      <input type="text" class="form-control rounded-pill" placeholder=" subject" name="subject" value="<?php echo $row_feedbacks['subject'] ?>" required>
                    </div>
                    <?php
                    if ($row_feedbacks['image'] != NULL) {
                      ?>
                      <div class="clearfix"></div>
                      <img src="../<?php echo $row_feedbacks['image']; ?>" alt="../<?php echo $row_feedbacks['image']; ?>" class="mt-2 mb-2 border rounded-pill w-100">
                      <div class="clearfix"></div>
                      <?php
                    }
                    ?>
                    <div class="form-group">
                      <input type="file" class="form-control rounded-pill" name="photo" placeholder="image" accept="image/*">
                    </div>
                    <div class="form-group">
                      <textarea class="form-control rounded-pill" placeholder=" your feedback or complaint" rows="10" style="resize: none;" name="feedback" required><?php echo $row_feedbacks['feedback'] ?></textarea>
                    </div>
                    <div>
                      <center>
                        <a href="actions/feedback-delete.php?token=<?php echo $row_feedbacks['token'] ?>" class="btn btn-danger py-3 px-5">
                          Delete Feedback
                        </a>
                        <button type="submit" name="submit" class="btn btn-primary py-3 px-5">
                          Update Feedback
                        </button>
                      </center>
                    </div>
                  </div>
                </form>
              <?php
              } ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <hr>

  <?php require_once 'include/footer.php'; ?>



  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="js/main.js"></script>

</body>

</html>
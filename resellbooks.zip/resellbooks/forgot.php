<?php
session_start();
include('include/dbConnect.php');
include('include/helper.php');
$email = $_GET['email'];
$qryadmn = $db->prepare("SELECT * FROM users WHERE email = '$email'");
$qryadmn->execute();
if ($qryadmn->rowcount() > 0) {
    $rows = $qryadmn->fetch();

    $notification = '<html>
        <head>
        <title>HTML email</title>
        </head>
        <body>
        <h3>Hi ' . ucwords($rows['name']) . ', your password is "' .  ucwords($rows['password']) . '"</h3>
        <h3>Please update your password after login.</h3>
        </body>
        </html>';

    Notify($notification, $email);
    echo json_encode(array(
        "status" => 1,
        "message" => "Done",
    ));
} else {
    echo json_encode(array(
        "status" => 0,
        "message" => "Email not registered with us!",
    ));
    exit();
}

<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	<div class="container">
		<a class="navbar-brand" href="../"><img src="images/logo.png" width="50" class="mr-2">
		<span class="d-none d-md-inline-block">KITHAB MASTER</span>
	</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="oi oi-menu"></span> Menu
		</button>
		<div class="collapse navbar-collapse" id="ftco-nav">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item"><a href="../" class="nav-link">Home</a></li>
				<li class="nav-item"><a href="../shop.php" class="nav-link">Shop</a></li>
				<li class="nav-item"><a href="../contact.php" class="nav-link">Contact</a></li>
				<?php if (isset($_SESSION['SESS_USER_TOKEN']) && (trim($_SESSION['SESS_USER_TOKEN']) != '')) { ?>
					<li class="nav-item"><a href="../profile.php" class="nav-link">Profile</a></li>
					<?php if ($_SESSION['SESS_USER_TYPE'] == 'buyer') {
						$qry_cart = $db->prepare("SELECT * FROM cart WHERE cart_by = '" . $_SESSION['SESS_USER_TOKEN'] . "'");
						$qry_cart->execute();
					?>
						<li class="nav-item cta cta-colored"><a href="cart.php" class="nav-link"><span class="icon-shopping_cart"></span>[<?php echo $qry_cart->rowcount(); ?>]</a></li>
					<li class="nav-item"><a href="../logout.php" class="nav-link">Logout</a></li>
					<?php } ?>
				<?php } else { ?>
					<li class="nav-item"><a href="../login.php" class="nav-link">Login</a></li>
					<li class="nav-item"><a href="../register.php" class="nav-link">Register</a></li>
				<?php } ?>
			</ul>
		</div>
	</div>
</nav>
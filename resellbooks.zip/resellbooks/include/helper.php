<?php
function genToken()
{
    return 't' . sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x', mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000, mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff));
}
date_default_timezone_set("Asia/Kolkata");
$current_date_time_local_min = date("Y-m-d", time()).'T'.date("h:i", time());
$current_date_time_local = date("Y-m-d H:i:s", time());
$today_local = date("Y-m-d");
$current_time_local = date("H:i:s", time());
$current_time_local_plus_1 = date('H:i', strtotime('+1 hour', strtotime($current_time_local)));
$current_date_time_local_plus_2 = date('Y-m-d H:i:s', strtotime('+2 hour', strtotime($current_date_time_local)));
date_default_timezone_set('UTC');
$current_date_time = date("Y-m-d H:i:s", time());


function time_convert($date)
{
    $date = date_create($date);
    return date_format($date, "d/m/Y h:i A");
}
function time_convert2($date)
{
    $date = date_create($date);
    return date_format($date, "d/m/Y h:i:s A");
}

function time_differenceInSeconds($time)
{
    date_default_timezone_set("Asia/Kolkata");
    $current_date_time_local = date("Y-m-d H:i:s", time());
    $timeFirst  = strtotime($time);
    $timeSecond = strtotime($current_date_time_local);
    $differenceInSeconds = $timeSecond - $timeFirst;
    return $differenceInSeconds;
}
function time_differenceInSeconds_2($time, $time2)
{
    $timeFirst  = strtotime($time);
    $timeSecond = strtotime($time2);
    $differenceInSeconds = $timeSecond - $timeFirst;
    return $differenceInSeconds;
}

function date_format_local($date, $format)
{
    return date_format(date_create($date), $format);
}
$base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'].'/';


function Notify($notification, $email_to)
{
    $to = $email_to;
    $subject = 'Mail from Kithab Master';
    // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    // More headers
    $headers .= 'From: <kithabmaster@krabd.com>' . "\r\n";
    $mail_sent = mail($to, $subject, $notification, $headers);
    return $mail_sent ? "" : "";
}


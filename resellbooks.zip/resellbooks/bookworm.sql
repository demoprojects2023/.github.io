-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2022 at 11:47 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookworm`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` bigint(21) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_by` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `category` text NOT NULL,
  `author` text DEFAULT NULL,
  `pages` int(21) DEFAULT NULL,
  `year` varchar(4) NOT NULL,
  `mrp` decimal(13,2) NOT NULL,
  `rate` decimal(13,2) NOT NULL,
  `act_stock` int(12) NOT NULL,
  `stock` int(11) NOT NULL,
  `city` varchar(255) NOT NULL,
  `about` longtext NOT NULL,
  `image` longtext NOT NULL,
  `created_at` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `approved_on` datetime DEFAULT NULL,
  `edited` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `token`, `created_by`, `title`, `category`, `author`, `pages`, `year`, `mrp`, `rate`, `act_stock`, `stock`, `city`, `about`, `image`, `created_at`, `status`, `approved`, `approved_on`, `edited`) VALUES
(1, 't2c9d4e50-5631-4531-9224-eb74d6cfd8fb', 't841959a5-dca6-4cd7-9fbb-b43538b84595', 'Eternity Springs: The McBrides of Texas Ever Tucker', 'hse books', 'author name', 50, '2010', '500.00', '260.00', 3, 3, 'palakkad', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat.', 'images/books/t5dcbb17a-7868-4fbd-bc38-639499d4efad.jpg', '2022-07-21 15:21:05', 1, 1, '2022-07-23 23:12:19', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` bigint(21) NOT NULL,
  `cart_by` varchar(255) NOT NULL,
  `book` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `cart_by`, `book`) VALUES
(7, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 't2c9d4e50-5631-4531-9224-eb74d6cfd8fb');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(21) NOT NULL,
  `token` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `token`, `name`, `status`, `created_at`) VALUES
(1, 'tcdb9b683-b41f-42c2-b9ed-4f558b42a1d3', 'hse books', 1, '2022-07-20 21:52:35'),
(2, 't83b55864-64bc-48b4-bd68-71ad964ea29e', 'sslc books', 1, '2022-07-20 21:56:27'),
(3, 't3b8d5115-344e-4674-9654-ea5cc16e7163', 'new cat', 1, '2022-07-23 11:57:59');

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL,
  `chat_with` varchar(255) NOT NULL,
  `sender_token` text NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime NOT NULL,
  `msg_read` int(1) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `chat_with`, `sender_token`, `message`, `created_at`, `msg_read`, `status`) VALUES
(1, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'hi', '2022-07-21 18:42:15', 1, 1),
(2, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'are you there?', '2022-07-21 18:42:31', 1, 1),
(3, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'lorem Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deleniti unde eum iusto, non mollitia ullam, voluptatibus laboriosam quam voluptas dolor fugiat sunt? Voluptatibus culpa laudantium magnam modi eius debitis consequatur.', '2022-07-21 18:42:43', 1, 1),
(4, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'KJSDNKJWHNDKWHJNWKJNKDJJNKWJNKJNFL', 'hi', '2022-07-21 19:08:32', 1, 1),
(5, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'hi', '2022-07-21 19:09:10', 1, 1),
(6, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'KJSDNKJWHNDKWHJNWKJNKDJJNKWJNKJNFL', 'hi', '2022-07-21 19:19:12', 1, 1),
(7, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'KJSDNKJWHNDKWHJNWKJNKDJJNKWJNKJNFL', 'gi', '2022-07-21 19:19:18', 1, 1),
(8, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'KJSDNKJWHNDKWHJNWKJNKDJJNKWJNKJNFL', 'hi', '2022-07-21 19:20:17', 1, 1),
(9, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'KJSDNKJWHNDKWHJNWKJNKDJJNKWJNKJNFL', 'hi', '2022-07-21 19:21:46', 1, 1),
(10, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'KJSDNKJWHNDKWHJNWKJNKDJJNKWJNKJNFL', 'hi', '2022-07-21 19:22:42', 1, 1),
(11, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'hi', '2022-07-21 19:22:53', 1, 1),
(12, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'hi', '2022-07-21 19:23:00', 1, 1),
(13, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'hi', '2022-07-21 19:26:33', 1, 1),
(14, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'available', '2022-07-21 19:26:47', 1, 1),
(15, 't841959a5-dca6-4cd7-9fbb-b43538b84595', 't841959a5-dca6-4cd7-9fbb-b43538b84595', 'hi', '2022-07-21 19:46:28', 1, 1),
(16, 't841959a5-dca6-4cd7-9fbb-b43538b84595', 't841959a5-dca6-4cd7-9fbb-b43538b84595', 'are you there?', '2022-07-21 19:46:33', 1, 1),
(17, 't841959a5-dca6-4cd7-9fbb-b43538b84595', 'KJSDNKJWHNDKWHJNWKJNKDJJNKWJNKJNFL', 'yes', '2022-07-21 19:47:00', 1, 1),
(18, 't841959a5-dca6-4cd7-9fbb-b43538b84595', 'KJSDNKJWHNDKWHJNWKJNKDJJNKWJNKJNFL', 'how can i help you?', '2022-07-21 19:47:06', 1, 1),
(19, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'KJSDNKJWHNDKWHJNWKJNKDJJNKWJNKJNFL', 'hi', '2022-07-22 14:37:11', 1, 1),
(20, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'hi', '2022-07-23 11:54:39', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` bigint(21) NOT NULL,
  `name` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `state` varchar(255) DEFAULT 'Kerala',
  `country` varchar(255) DEFAULT 'India',
  `status` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `district`, `state`, `country`, `status`) VALUES
(1, 'Kozhikode', 'Kozhikode', 'Kerala', 'India', 1),
(2, 'Kochi', 'Ernakulam', 'Kerala', 'India', 1),
(3, 'Kollam', 'Kollam', 'Kerala', 'India', 1),
(4, 'Thrissur', 'Thrissur', 'Kerala', 'India', 1),
(5, 'Kannur', 'Kannur', 'Kerala', 'India', 1),
(6, 'Alappuzha', 'Alappuzha', 'Kerala', 'India', 1),
(7, 'Kottayam', 'Kottayam', 'Kerala', 'India', 1),
(8, 'Palakkad', 'Palakkad', 'Kerala', 'India', 1),
(9, 'Manjeri', 'Malappuram', 'Kerala', 'India', 1),
(10, 'Thalassery', 'Kannur', 'Kerala', 'India', 1),
(11, 'Ponnani', 'Malappuram', 'Kerala', 'India', 1),
(12, 'Vatakara', 'Kozhikode', 'Kerala', 'India', 1),
(13, 'Kanhangad', 'Kasaragod', 'Kerala', 'India', 1),
(14, 'Payyanur', 'Kannur', 'Kerala', 'India', 1),
(15, 'Koyilandy', 'Kozhikode', 'Kerala', 'India', 1),
(16, 'Parappanangadi', 'Malappuram', 'Kerala', 'India', 1),
(17, 'Kalamassery', 'Ernakulam', 'Kerala', 'India', 1),
(18, 'Neyyattinkara', 'Thiruvananthapuram', 'Kerala', 'India', 1),
(19, 'Tanur', 'Malappuram', 'Kerala', 'India', 1),
(20, 'Thrippunithura', 'Ernakulam', 'Kerala', 'India', 1),
(21, 'Kayamkulam', 'Alappuzha', 'Kerala', 'India', 1),
(22, 'Malappuram', 'Malappuram', 'Kerala', 'India', 1),
(23, 'Thrikkakkara', 'Ernakulam', 'Kerala', 'India', 1),
(24, 'Wadakkancherry', 'Thrissur', 'Kerala', 'India', 1),
(25, 'Nedumangad', 'Thiruvananthapuram', 'Kerala', 'India', 1),
(26, 'Kondotty', 'Malappuram', 'Kerala', 'India', 1),
(27, 'Tirurangadi', 'Malappuram', 'Kerala', 'India', 1),
(28, 'Tirur', 'Malappuram', 'Kerala', 'India', 1),
(29, 'Panoor', 'Kannur', 'Kerala', 'India', 1),
(30, 'Nileshwaram', 'Kasaragod', 'Kerala', 'India', 1),
(31, 'Kasaragod', 'Kasaragod', 'Kerala', 'India', 1),
(32, 'Feroke', 'Kozhikode', 'Kerala', 'India', 1),
(33, 'Kunnamkulam', 'Thrissur', 'Kerala', 'India', 1),
(34, 'Ottappalam', 'Palakkad', 'Kerala', 'India', 1),
(35, 'Tiruvalla', 'Pathanamthitta', 'Kerala', 'India', 1),
(36, 'Thodupuzha', 'Idukki', 'Kerala', 'India', 1),
(37, 'Perinthalmanna', 'Malappuram', 'Kerala', 'India', 1),
(38, 'Chalakudy', 'Thrissur', 'Kerala', 'India', 1),
(39, 'Payyoli', 'Kozhikode', 'Kerala', 'India', 1),
(40, 'Koduvally', 'Kozhikode', 'Kerala', 'India', 1),
(41, 'Mananthavady', 'Wayanad', 'Kerala', 'India', 1),
(42, 'Changanassery', 'Kottayam', 'Kerala', 'India', 1),
(43, 'Mattanur', 'Kannur', 'Kerala', 'India', 1),
(44, 'Punalur', 'Kollam', 'Kerala', 'India', 1),
(45, 'Nilambur', 'Malappuram', 'Kerala', 'India', 1),
(46, 'Cherthala', 'Alappuzha', 'Kerala', 'India', 1),
(47, 'Sultan Bathery', 'Wayanad', 'Kerala', 'India', 1),
(48, 'Maradu', 'Ernakulam', 'Kerala', 'India', 1),
(49, 'Kottakkal', 'Malappuram', 'Kerala', 'India', 1),
(50, 'Taliparamba', 'Kannur', 'Kerala', 'India', 1),
(51, 'Shornur', 'Palakkad', 'Kerala', 'India', 1),
(52, 'Pandalam', 'Pathanamthitta', 'Kerala', 'India', 1),
(53, 'Kattappana', 'Idukki', 'Kerala', 'India', 1),
(54, 'Mukkam', 'Kozhikode', 'Kerala', 'India', 1),
(55, 'Iritty', 'Kannur', 'Kerala', 'India', 1),
(56, 'Valanchery', 'Malappuram', 'Kerala', 'India', 1),
(57, 'Varkala', 'Thiruvananthapuram', 'Kerala', 'India', 1),
(58, 'Cherpulassery', 'Palakkad', 'Kerala', 'India', 1),
(59, 'Chavakkad', 'Thrissur', 'Kerala', 'India', 1),
(60, 'Kothamangalam', 'Ernakulam', 'Kerala', 'India', 1),
(61, 'Pathanamthitta', 'Pathanamthitta', 'Kerala', 'India', 1),
(62, 'Attingal', 'Thiruvananthapuram', 'Kerala', 'India', 1),
(63, 'Paravur', 'Kollam', 'Kerala', 'India', 1),
(64, 'Ramanattukara', 'Kozhikode', 'Kerala', 'India', 1),
(65, 'Mannarkkad', 'Palakkad', 'Kerala', 'India', 1),
(66, 'Erattupetta', 'Kottayam', 'Kerala', 'India', 1),
(67, 'Kodungallur', 'Thrissur', 'Kerala', 'India', 1),
(68, 'Sreekandapuram', 'Kannur', 'Kerala', 'India', 1),
(69, 'Angamaly', 'Ernakulam', 'Kerala', 'India', 1),
(70, 'Chittur-Thathamangalam', 'Palakkad', 'Kerala', 'India', 1),
(71, 'Kalpetta', 'Wayanad', 'Kerala', 'India', 1),
(72, 'North Paravur', 'Ernakulam', 'Kerala', 'India', 1),
(73, 'Haripad', 'Alappuzha', 'Kerala', 'India', 1),
(74, 'Muvattupuzha', 'Ernakulam', 'Kerala', 'India', 1),
(75, 'Kottarakara', 'Kollam', 'Kerala', 'India', 1),
(76, 'Kuthuparamba', 'Kannur', 'Kerala', 'India', 1),
(77, 'Adoor', 'Pathanamthitta', 'Kerala', 'India', 1),
(78, 'Piravom', 'Ernakulam', 'Kerala', 'India', 1),
(79, 'Irinjalakuda', 'Thrissur', 'Kerala', 'India', 1),
(80, 'Pattambi', 'Palakkad', 'Kerala', 'India', 1),
(81, 'Anthoor', 'Kannur', 'Kerala', 'India', 1),
(82, 'Perumbavoor', 'Ernakulam', 'Kerala', 'India', 1),
(83, 'Ettumanoor', 'Kottayam', 'Kerala', 'India', 1),
(84, 'Mavelikkara', 'Alappuzha', 'Kerala', 'India', 1),
(85, 'Karunagappalli', 'Kollam', 'Kerala', 'India', 1),
(86, 'Eloor', 'Ernakulam', 'Kerala', 'India', 1),
(87, 'Chengannur', 'Alappuzha', 'Kerala', 'India', 1),
(88, 'Vaikom', 'Kottayam', 'Kerala', 'India', 1),
(89, 'Aluva', 'Ernakulam', 'Kerala', 'India', 1),
(90, 'Pala', 'Kottayam', 'Kerala', 'India', 1),
(91, 'Guruvayur', 'Thrissur', 'Kerala', 'India', 1),
(92, 'Koothattukulam', 'Ernakulam', 'Kerala', 'India', 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` bigint(21) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `subject` text DEFAULT NULL,
  `feedback` longtext DEFAULT NULL,
  `image` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply` longtext DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`id`, `token`, `created_by`, `subject`, `feedback`, `image`, `created_at`, `reply`, `status`) VALUES
(2, 't8f6334e2-ccf3-4ece-9fcf-b6284d92eac2', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'Something I really appreciate about you is...', 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugiat ducimus atque recusandae sequi ipsum rerum rem. Neque dolorum quasi commodi odit amet vero molestias dolore autem quos reprehenderit, nostrum laudantium. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugiat ducimus atque recusandae sequi ipsum rerum rem. Neque dolorum quasi commodi odit amet vero molestias dolore autem quos reprehenderit, nostrum laudantium.', '', '2022-05-28 17:57:25', 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugiat ducimus atque recusandae sequi ipsum rerum rem. Neque dolorum quasi commodi odit amet vero molestias dolore autem quos reprehenderit, nostrum laudantium. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugiat ducimus atque recusandae sequi ipsum rerum rem. Neque dolorum quasi commodi odit amet vero molestias dolore autem quos reprehenderit, nostrum laudantium.', NULL),
(4, 't2522fa3b-3e75-4e45-850b-818e5f36f686', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'subject', 'new feedback', '', '2022-07-21 16:43:38', 'reply', NULL),
(5, 't458270e9-cde8-499b-9d02-8bea7aee8373', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'sugsjnd', 'adsasads', 'images/feedback/t05bfd887-3a8d-4831-8fe3-afaed3c41f1b.jpg', '2022-07-23 19:41:06', NULL, NULL),
(6, 'ta96dc29a-bf23-4e3e-bd32-e6d985e0a61c', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'gdgdgdf', 'fdggdfgdf', 'images/feedback/t787be569-f85b-435f-b3e8-fd001efbb3da.jpg', '2022-07-23 19:46:08', NULL, NULL),
(7, 't45e6810f-07ef-4e95-bdd9-d6113bd1f6ab', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'sdfds', 'dsfsf', 'images/feedback/t5075668d-bccf-406b-9c8b-31f99f350981.jpg', '2022-07-23 19:52:59', NULL, NULL),
(8, 't5e63bd31-a58f-4c76-8f6e-b606cedddaf1', '', '', '', '', '2022-07-24 12:40:19', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(21) NOT NULL,
  `token` varchar(255) NOT NULL,
  `order_to` varchar(255) NOT NULL,
  `order_by` varchar(255) NOT NULL,
  `book` varchar(255) NOT NULL,
  `total` decimal(13,2) NOT NULL,
  `location` text NOT NULL,
  `street_1` text DEFAULT NULL,
  `street_2` text DEFAULT NULL,
  `landmark` text DEFAULT NULL,
  `zip` int(6) NOT NULL,
  `email` text NOT NULL,
  `contact_no` varchar(15) NOT NULL,
  `created_at` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `order_status` text NOT NULL DEFAULT 'order placed',
  `delivered_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `token`, `order_to`, `order_by`, `book`, `total`, `location`, `street_1`, `street_2`, `landmark`, `zip`, `email`, `contact_no`, `created_at`, `status`, `order_status`, `delivered_at`) VALUES
(2, 'tb8927b90-d9e1-4dbc-b27e-b6cf1caf2230', 't841959a5-dca6-4cd7-9fbb-b43538b84595', 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 't2c9d4e50-5631-4531-9224-eb74d6cfd8fb', '260.00', 'Palakkad, Kerala, India', 'house name', 'apartment number ', '', 678854, 'buyer@mail.com', '9874525252', '2022-07-21 15:33:01', 1, 'delivered', '2022-07-21 15:51:30');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(21) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `user_type` varchar(255) DEFAULT NULL COMMENT 'admin/seller/buyer',
  `name` varchar(255) DEFAULT NULL,
  `email` text DEFAULT NULL,
  `contact_no` varchar(12) DEFAULT NULL,
  `profile_dp` longtext DEFAULT NULL,
  `city` text DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `bio` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `remember_token` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `token`, `user_type`, `name`, `email`, `contact_no`, `profile_dp`, `city`, `password`, `status`, `bio`, `created_at`, `remember_token`) VALUES
(1, 'KJSDNKJWHNDKWHJNWKJNKDJJNKWJNKJNFL', 'admin', 'Admin', 'admin@mail.com', NULL, NULL, NULL, '12345', 1, NULL, '2022-03-07 18:03:29', 't40bb7412-9606-487f-8222-a69202a7a023'),
(15, 't841959a5-dca6-4cd7-9fbb-b43538b84595', 'seller', 'sajeesh rajan', 'seller@mail.com', '9846525252', NULL, 'palakkad', '123456', 1, NULL, '2022-07-20 18:43:21', 'tc31067e4-3102-4d50-8c2e-1a823756a4c5'),
(16, 't2fac5079-74af-4a71-95d4-6463f80ad1f5', 'buyer', 'Buyer Name', 'buyer@mail.com', '9874525252', 'images/dp/t706bb430-9317-4574-8234-1b71640fb8ff.jpg', 'palakkad', '123456789', 1, NULL, '2022-07-21 00:42:13', 't02d8e36d-6918-48eb-984b-51c344312394');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` bigint(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` bigint(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` bigint(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

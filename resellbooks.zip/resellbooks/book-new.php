<?php
include('include/auth-all.php');
include('include/dbConnect.php');
include('include/helper.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>KITHAB MASTER</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/ionicons.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">


	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
</head>

<body class="goto-here">
	<?php require_once 'include/header.php'; ?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
		<div class="container">
			<div class="row no-gutters slider-text align-items-center justify-content-center">
				<div class="col-md-9 ftco-animate text-center">
					<h1 class="mb-0 breadd font-weight-bolder text-white">NEW BOOK</h1>
				</div>
			</div>
		</div>
	</div>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-12 ftco-animate">
					<div class="card card-rounded shadow-lg">
						<div class="card-body">
							<form action="" id="submitForm" autocomplete="off">
								<h2 class="mb-3 bbilling-heading font-weight-bolder text-center">ADD NEW BOOK TO SELL</h2>
								<div class="row align-items-end">
									<div class="col-md-12">
										<div class="form-group">
											<input type="text" name="title" class="form-control text-dark rounded-pill" placeholder="book title" required>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<select name="category" id="" class="form-control text-dark rounded-pill" required>
												<option value="">Choose category</option>
												<?php
												$qry_categories = $db->prepare("SELECT * FROM categories WHERE status = 1 ORDER BY name");
												$qry_categories->execute();
												for ($i = 1; $row_categories = $qry_categories->fetch(); $i++) {
													echo '<option value="' . ($row_categories['name']) . '">' . strtoupper($row_categories['name']) . '</option>';
												}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<input type="text" name="author" class="form-control text-dark rounded-pill" placeholder="Author" required>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<input type="number" name="pages" class="form-control text-dark rounded-pill" placeholder="no. of pages" required>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<input type="number" name="year" class="form-control text-dark rounded-pill" placeholder="book published year" required>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<input type="number" name="mrp" class="form-control text-dark rounded-pill" placeholder="book actual price" required>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<input type="number" name="rate" class="form-control text-dark rounded-pill" placeholder="book selling price" required>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<input type="number" name="stock" class="form-control text-dark rounded-pill" placeholder="book stock" required>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<select name="city" class="form-control text-dark rounded-pill" required>
												<option value="">Choose city to sell</option>
												<?php
												$qry_cities = $db->prepare("SELECT * FROM cities GROUP BY district ORDER BY district");
												$qry_cities->execute();
												for ($i = 1; $row_cities = $qry_cities->fetch(); $i++) {
													echo '<option value="' . strtolower($row_cities['district']) . '">' . $row_cities['district'] . ', ' . $row_cities['state'] . ', ' . $row_cities['country'] . '</option>';
												}
												?>
											</select>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<textarea class="form-control text-dark rounded-pill" name="about" placeholder="book details" rows="15" required></textarea>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<input type="file" name="upload-Image" class="form-control text-dark rounded-pill" accept="image/*" required aria-required="true">
										</div>
									</div>
                                        <div class="col-12">
                                            <p class="text-danger text-center"><b><span id="eeerrr"></span></b></p>
                                        </div>
									<div class="col-md-12 border-top pt-4 pb-3 text-center">
										<a href="../profile.php" class="btn btn-danger py-3 px-5">CANCEL</a>
										<button type="submit" name="submit" class="btn btn-primary py-3 px-5">SUBMIT FOR VERIFICATION</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<hr>
	<?php require_once 'include/footer.php'; ?>
	<script src="js/jquery.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="js/main.js"></script>
	<script>
		$('#submitForm').on('submit', (function(e) {
			e.preventDefault();
			var formData = new FormData(this);
			$.ajax({
				type: 'POST',
				url: "actions/book-save.php",
				data: formData,
				dataType: 'JSON',
				cache: false,
				contentType: false,
				processData: false,
				success: function(data) {
					var result = JSON.parse(JSON.stringify(data));
					console.log(result.status);
					if (result.status == 1) {
						window.location.href = "../books.php";
					} else {
						$("#eeerrr").text(result.message);
					}
				},
				error: function(data) {
					console.log(data);
				}
			});
		}));
	</script>
</body>

</html>
<?php
include('include/auth-all.php');
include('include/dbConnect.php');
include('include/helper.php');
$title = 'ORDERS - PENDING';
if (!isset($_GET['status'])) {
	header("location:orders.php?status=0");
}
$status = $_GET['status'];
if ($status == 1) {
	$title = 'ORDERS - DELIVERED';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>KITHAB MASTER</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/ionicons.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">


	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
</head>

<body class="goto-here">
	<?php require_once 'include/header.php'; ?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
		<div class="container">
			<div class="row no-gutters slider-text align-items-center justify-content-center">
				<div class="col-md-9 ftco-animate text-center">
					<h1 class="mb-0 breadd font-weight-bolder text-white"><?php echo $title ?></h1>
				</div>
			</div>
		</div>
	</div>
	<section class="ftco-section bg-light">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="row">
						<?php
						if ($_SESSION['SESS_USER_TYPE'] == 'seller') {
							$qry = "SELECT * FROM orders WHERE order_to = '$user' AND delivered_at IS NOT NULL ORDER BY id DESC";
							if ($status == 0) {
								$qry = "SELECT * FROM orders WHERE order_to = '$user' AND delivered_at IS NULL ORDER BY id DESC";
							}
							$qry_order = $db->prepare($qry);
							$qry_order->execute();
							if ($qry_order->rowCount() > 0) {
								for ($i = 1; $row_order = $qry_order->fetch(); $i++) {
									$qry_book = $db->prepare("SELECT * FROM books WHERE token = '" . $row_order['book'] . "'");
									$qry_book->execute();
									$row_book = $qry_book->fetch();

									$qry_user = $db->prepare("SELECT * FROM users WHERE token = '" . $row_order['order_by'] . "'");
									$qry_user->execute();
									$row_user = $qry_user->fetch();
						?>
									<div class="col-12">
										<div class="dashCard mb-4 mr-4">
											<div class="card shadow-lg card-rounded">
												<div class="card-content">
													<div class="card-body">
														<div class="row">
															<div class="col-md-10">
																<div class="media d-flex">
																	<div class="media-body text-left">
																		<p class="mb-0 text-dark font-weight-bold"><?php echo strtoupper(date_format_local($row_order['created_at'], 'd M Y h:i A')) ?></p>
																		<h3 class="mb-0">#<?php echo ucwords($row_order['id']) ?> - <?php echo ucwords($row_book['title']) ?></h3>
																		<?php
																		if ($row_order['delivered_at'] == NULL) {
																			echo '<p class="mb-0 text-success font-weight-bold">STATUS: ' . strtoupper($row_order['order_status']) . '</p>';
																		} else {
																			echo '<p class="mb-0 text-danger font-weight-bold">STATUS: DELIVERED AT ' . strtoupper(date_format_local($row_order['delivered_at'], 'd M Y h:i A'));
																		}
																		?>
																		<p class="mb-0 text-dark font-weight-bold">
																			DELIVER TO:
																			<?php echo strtoupper($row_user['name']) ?> -
																			<?php echo strtoupper($row_order['location'] . ", " . $row_order['street_1'] . ", " . $row_order['street_2'] . " - " . $row_order['zip']) ?>
																		</p>
																	</div>
																</div>
															</div>
															<div class="col-md-2">
																<p class="mb-0 text-center">ACTIONS</p>
																<a href="tel:<?php echo $row_user['contact_no'] ?>" class="btn bg-success btn-block text-white mt-2 border-0">CALL BUYER</a>
																<?php if ($row_order['delivered_at'] == NULL) { ?>
																	<a href="actions/delivered.php?token=<?php echo $row_order['token'] ?>" class="btn bg-success btn-block text-white mt-2 border-0">DELIVERED</a>
																<?php } ?>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								<?php }
							} else { ?>
								<div class="ftco-animate col-12 mt-5 mb-5 pt-5 pb-5">
									<h1 class="text-center text-muted mt-5 mb-5">
										No Orders
									</h1>
								</div>
								<?php }
						} else if ($_SESSION['SESS_USER_TYPE'] == 'buyer') {
							$qry = "SELECT * FROM orders WHERE order_by = '$user' AND delivered_at IS NOT NULL ORDER BY id DESC";
							if ($status == 0) {
								$qry = "SELECT * FROM orders WHERE order_by = '$user' AND delivered_at IS NULL ORDER BY id DESC";
							}
							$qry_order = $db->prepare($qry);
							$qry_order->execute();
							if ($qry_order->rowCount() > 0) {
								for ($i = 1; $row_order = $qry_order->fetch(); $i++) {
									$qry_book = $db->prepare("SELECT * FROM books WHERE token = '" . $row_order['book'] . "'");
									$qry_book->execute();
									$row_book = $qry_book->fetch();

									$qry_user = $db->prepare("SELECT * FROM users WHERE token = '" . $row_order['order_to'] . "'");
									$qry_user->execute();
									$row_user = $qry_user->fetch();
								?>
									<div class="col-12">
										<div class="dashCard mb-4 mr-4">
											<div class="card shadow-lg card-rounded">
												<div class="card-content">
													<div class="card-body">
														<div class="row">
															<div class="col-md-10">
																<div class="media d-flex">
																	<div class="media-body text-left">
																		<p class="mb-0 text-dark font-weight-bold"><?php echo strtoupper(date_format_local($row_order['created_at'], 'd M Y h:i A')) ?></p>
																		<h3 class="mb-0">#<?php echo ucwords($row_order['id']) ?> - <?php echo ucwords($row_book['title']) ?></h3>
																		<?php
																		if ($row_order['delivered_at'] == NULL) {
																			echo '<p class="mb-0 text-success font-weight-bold">STATUS: ' . strtoupper($row_order['order_status']) . '</p>';
																		} else {
																			echo '<p class="mb-0 text-danger font-weight-bold">STATUS: DELIVERED AT ' . strtoupper(date_format_local($row_order['delivered_at'], 'd M Y h:i A'));
																		}
																		?>
																		<p class="mb-0 text-dark font-weight-bold">
																			DELIVER TO: <?php echo strtoupper($row_order['location'] . ", " . $row_order['street_1'] . ", " . $row_order['street_2'] . " - " . $row_order['zip']) ?>
																		</p>
																	</div>
																</div>
															</div>
															<div class="col-md-2">
																<p class="mb-0 text-center">ACTIONS</p>
																<a href="tel:<?php echo $row_user['contact_no'] ?>" class="btn bg-success btn-block text-white mt-2 border-0">CALL SELLER</a>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								<?php }
							} else { ?>
								<div class="ftco-animate col-12 mt-5 mb-5 pt-5 pb-5">
									<h1 class="text-center text-muted mt-5 mb-5">
										No Orders
									</h1>
								</div>
						<?php }
						} ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<hr>

	<?php require_once 'include/footer.php'; ?>



	<script src="js/jquery.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
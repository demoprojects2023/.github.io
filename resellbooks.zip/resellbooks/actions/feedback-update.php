<?php
session_start();
include('../include/dbConnect.php');
include('../include/helper.php');

$user = trim($_SESSION['SESS_USER_TOKEN']);
$subject = $_POST['subject'];
$feedback = $_POST['feedback'];
$token = $_POST['token'];

if (isset($_FILES['photo']) && $_FILES['photo']['name'] != "") {
    $target_dir = "../images/feedback/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
    $image_name = addslashes($_FILES['photo']['name']);
    $image_size = getimagesize($_FILES['photo']['tmp_name']);
    $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
    $image = genToken() . '.' . $ext;
    move_uploaded_file($_FILES["photo"]["tmp_name"], "../images/feedback/" . $image);
    $saveimage = "images/feedback/" . $image;

    
    $db->prepare("UPDATE feedbacks SET subject = '$subject', feedback = '$feedback', created_at = '$current_date_time_local', image = '$saveimage' WHERE token = '$token'")->execute();
} else {
    $db->prepare("UPDATE feedbacks SET subject = '$subject', feedback = '$feedback', created_at = '$current_date_time_local' WHERE token = '$token'")->execute();
}
header("location:../feedbacks.php");

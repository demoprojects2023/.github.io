<?php
session_start();
include('../include/dbConnect.php');
include('../include/helper.php');
$cart_by = trim($_SESSION['SESS_USER_TOKEN']);

$db->prepare("DELETE FROM cart WHERE cart_by = '$cart_by'")->execute();

header("location:../cart.php");

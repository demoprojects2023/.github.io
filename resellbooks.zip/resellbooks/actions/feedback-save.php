<?php
session_start();
include('../include/dbConnect.php');
include('../include/helper.php');

$user = trim($_SESSION['SESS_USER_TOKEN']);
$subject = $_POST['subject'];
$feedback = $_POST['feedback'];
if (isset($_FILES['photo']) && $_FILES['photo']['name'] != "") {
    $target_dir = "../images/feedback/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
    $image_name = addslashes($_FILES['photo']['name']);
    $image_size = getimagesize($_FILES['photo']['tmp_name']);
    $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
    $image = genToken() . '.' . $ext;
    move_uploaded_file($_FILES["photo"]["tmp_name"], "../images/feedback/" . $image);
    $saveimage = "images/feedback/" . $image;
} else {
    $saveimage = NULL;
    $token = genToken();
    $db->prepare("INSERT INTO feedbacks (token, subject, feedback, created_at, created_by, image) VALUES ('$token', '$subject', '$feedback', '$current_date_time_local', '$user', '$saveimage')")->execute();
}
header("location:../feedbacks.php");

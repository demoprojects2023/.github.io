<?php
session_start();
include('../include/dbConnect.php');
include('../include/helper.php');
$token = $_GET['token'];

$db->prepare("UPDATE orders SET order_status = 'delivered', delivered_at = '$current_date_time_local' WHERE token = '$token'")->execute();


$qry_order = $db->prepare("SELECT * FROM orders WHERE token = '$token'");
$qry_order->execute();
$row_order = $qry_order->fetch();
$order_to = $row_order['order_to'];
$qry_user = $db->prepare("SELECT * FROM users WHERE token = '$order_to'");
$qry_user->execute();
$row_user = $qry_user->fetch();
$email_to = $row_user['email'];
$notification = 'You Order Delivered, please check Orders.';
Notify($notification, $email_to);

header("location:../orders.php");

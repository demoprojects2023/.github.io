<?php
session_start();
include('../include/dbConnect.php');
include('../include/helper.php');
$created_by = $_SESSION['SESS_USER_TOKEN'];

$message = '';
$target_dir = "../images/books/";
$fileName =  genToken();
$savePath = "images/books/";
if (!file_exists($target_dir)) {
    mkdir($target_dir, 0777, true);
}
$target_file = $target_dir . basename($_FILES["upload-Image"]["name"]);
$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
$target_file = $target_dir . $fileName . '.' . $imageFileType;
$savePath = $savePath . $fileName . '.' . $imageFileType;

$uploadOk = 1;

// Check if image file is a actual image or fake image
if (isset($_POST["submit"])) {
    $check = getimagesize($_FILES["upload-Image"]["tmp_name"]);
    if ($check !== false) {
        $message = "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        $message = "File is not an image.";
        $uploadOk = 0;
    }
}

// Check if file already exists
if (file_exists($target_file)) {
    $message = "Sorry, file already exists.";
    $uploadOk = 0;
}

// Check file size
if ($_FILES["upload-Image"]["size"] > 1500000) {
    $message = "Sorry, your file is too large (max size 1.5MB).";
    $uploadOk = 0;
}

// Allow certain file formats
if (
    $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif"
) {
    $message = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    $message .= " Your file was not uploaded.";
    // if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["upload-Image"]["tmp_name"], $target_file)) {
        $uploadOk = 1;
        $message = "The file has been uploaded.";
    } else {
        $uploadOk = 0;
        $message = "Sorry, there was an error uploading your file.";
    }
}
if ($uploadOk == 1) {
    $token = genToken();
    $title = $_POST['title'];
    $category = $_POST['category'];
    $year = $_POST['year'];
    $mrp = $_POST['mrp'];
    $rate = $_POST['rate'];
    $stock = $_POST['stock'];
    $city = $_POST['city'];
    $about = $_POST['about'];
    $act_stock = $_POST['stock'];
    $author = $_POST['author'];
    $pages = $_POST['pages'];
    $created_at = $current_date_time_local;

    $stmt = $db->prepare("INSERT INTO books(token, category, year, mrp, rate, stock, city, about, created_at, image, title, act_stock, created_by, author, pages) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bindParam(1, $token);
    $stmt->bindParam(2, $category);
    $stmt->bindParam(3, $year);
    $stmt->bindParam(4, $mrp);
    $stmt->bindParam(5, $rate);
    $stmt->bindParam(6, $stock);
    $stmt->bindParam(7, $city);
    $stmt->bindParam(8, $about);
    $stmt->bindParam(9, $created_at);
    $stmt->bindParam(10, $savePath);
    $stmt->bindParam(11, $title);
    $stmt->bindParam(12, $act_stock);
    $stmt->bindParam(13, $created_by);
    $stmt->bindParam(14, $author);
    $stmt->bindParam(15, $pages);
    $stmt->execute();
}
echo json_encode(array(
    "status" => $uploadOk,
    "message" => $message
));
exit();

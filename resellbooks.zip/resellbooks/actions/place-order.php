<?php
session_start();
include('../include/dbConnect.php');
include('../include/helper.php');
$order_by = trim($_SESSION['SESS_USER_TOKEN']);

$token = genToken();
$order_to = ($_POST["order_to"]);
$book = ($_POST["book"]);
$total = ($_POST["total"]);
$location = ($_POST["location"]);
$street_1 = ($_POST["street_1"]);
$street_2 = ($_POST["street_2"]);
$landmark = ($_POST["landmark"]);
$zip = ($_POST["zip"]);
$email = ($_POST["email"]);
$contact_no = ($_POST["contact_no"]);
$created_at = $current_date_time_local;
$status = 1;
$order_status = 'order placed';

$stmt = $db->prepare("INSERT INTO orders (token, order_to, order_by, book, total, location, street_1, street_2, landmark, zip, email, contact_no, created_at, status, order_status) VALUES (:token, :order_to, :order_by, :book, :total, :location, :street_1, :street_2, :landmark, :zip, :email, :contact_no, :created_at, :status, :order_status)");
$stmt->execute([':token' => $token, ':order_to' => $order_to, ':order_by' => $order_by, ':book' => $book, ':total' => $total, ':location' => $location, ':street_1' => $street_1, ':street_2' => $street_2, ':landmark' => $landmark, ':zip' => $zip, ':email' => $email, ':contact_no' => $contact_no, ':created_at' => $created_at, ':status' => $status, ':order_status' => $order_status]);

$db->prepare("UPDATE books SET stock = (stock - 1) WHERE  token = '$book'")->execute();
$db->prepare("DELETE FROM cart WHERE cart_by = '$cart_by'")->execute();

$qry_user = $db->prepare("SELECT * FROM users WHERE token = '$order_to'");
$qry_user->execute();
$row_user = $qry_user->fetch();
$email_to = $row_user['email'];
$notification = 'New Order Recieved, please check Orders.';
Notify($notification, $email_to);

echo json_encode(array(
    "status" => 1,
    "message" => 'Done'
));
exit();

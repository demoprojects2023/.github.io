<?php
session_start();
include('../include/dbConnect.php');
include('../include/helper.php');

$user = trim($_SESSION['SESS_USER_TOKEN']);
$token = $_GET['token'];

$db->prepare("DELETE FROM feedbacks WHERE token = '$token'")->execute();

header("location:../feedbacks.php");
<?php
session_start();
include('../include/dbConnect.php');
include('../include/helper.php');

$user = trim($_SESSION['SESS_USER_TOKEN']);
$name = $_POST['name'];
$city = $_POST['city'];
$contact_no = $_POST['contact_no'];

if (isset($_FILES['photo']) && $_FILES['photo']['name'] != "") {
    $target_dir = "../images/dp/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
    $image_name = addslashes($_FILES['photo']['name']);
    $image_size = getimagesize($_FILES['photo']['tmp_name']);
    $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
    $image = genToken() . '.' . $ext;
    move_uploaded_file($_FILES["photo"]["tmp_name"], "../images/dp/" . $image);
    $saveimage = "images/dp/" . $image;

    
    $db->prepare("UPDATE users SET name = '$name', city = '$city', contact_no = '$contact_no', profile_dp = '$saveimage' WHERE token = '$user'")->execute();
} else {
    $db->prepare("UPDATE users SET name = '$name', city = '$city', contact_no = '$contact_no' WHERE token = '$user'")->execute();
}
header("location:../profile.php");

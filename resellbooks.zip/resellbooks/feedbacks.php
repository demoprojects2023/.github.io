<?php
include('include/auth-all.php');
include('include/dbConnect.php');
include('include/helper.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>KITHAB MASTER</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

  <base href="<?php echo $base_url ?>" />
  <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
  <link rel="stylesheet" href="css/animate.css">

  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">

  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/ionicons.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">
  <link rel="stylesheet" href="css/jquery.timepicker.css">


  <link rel="stylesheet" href="css/flaticon.css">
  <link rel="stylesheet" href="css/icomoon.css">
  <link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
</head>

<body class="goto-here">
  <?php require_once 'include/header.php'; ?>
  <div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
    <div class="container">
      <div class="row no-gutters slider-text align-items-center justify-content-center">
        <div class="col-md-9 ftco-animate text-center">
          <h1 class="mb-0 breadd font-weight-bolder text-white">Feedbacks</h1>
        </div>
      </div>
    </div>
  </div>
  <section class="ftco-section contact-section bg-light">
    <div class="container">
      <div class="col-12">
        <a href="feedback-manage.php" class="btn btn-black py-2 px-5 mb-5">SEND FEEDBACK</a>
        <div id="accordion">
          <?php
          $qry = "SELECT * FROM feedbacks WHERE created_by = '$user' ORDER BY created_at DESC";

          $qry_feedbacks = $db->prepare($qry);
          $qry_feedbacks->execute();
          if ($qry_feedbacks->rowcount() > 0) {
            for ($i = 1; $row_feedbacks = $qry_feedbacks->fetch(); $i++) {
              $post_by = $row_feedbacks['created_by'];
              $qry = $db->prepare("SELECT * FROM users WHERE token = '$post_by'");
              $qry->execute();
              $row = $qry->fetch();
          ?>
              <div class="card mb-3">
                <div class="card-header p-0 bg-dark" id="heading<?php echo $i ?>">
                  <button class="btn btn-block text-left rounded text-white font-weight-bolder" style="font-size: 1.2rem;" data-toggle="collapse" data-target="#collapse<?php echo $i ?>" aria-expanded="true" aria-controls="collapse<?php echo $i ?>">
                    <?php echo ucwords($row_feedbacks['subject']) ?>
                    <small class="d-block text-left"><?php echo date_format_local($row_feedbacks['created_at'], 'd M Y h:m A') ?></small>
                  </button>
                </div>
                <div id="collapse<?php echo $i ?>" class="collapse" aria-labelledby="heading<?php echo $i ?>" data-parent="#accordion">
                  <div class="card-body">
                    <p class="mb-0 text-danger font-weight-bolder">
                      <?php
                      echo ucwords($row['name']) . " (" . ucwords($row['user_type']) . ")";
                      ?>
                    </p>
                    <?php
                    if ($row_feedbacks['image'] != NULL) {
                      ?>
                      <div class="clearfix"></div>
                      <img src="../<?php echo $row_feedbacks['image']; ?>" alt="../<?php echo $row_feedbacks['image']; ?>" class="mt-2 mb-2 border rounded" style="width:300px">
                      <div class="clearfix"></div>
                      <?php
                    }
                    ?>
                    <?php echo $row_feedbacks['feedback'];
                    if ($row_feedbacks['reply'] == NULL) { ?>
                      <div class="clearfix"></div>
                      <a href="feedback-manage.php?token=<?php echo $row_feedbacks['token'] ?>" class="btn btn-round btn-outline-primary mt-2 mr-1 mb-2">Edit Feedback</a>
                    <?php } else { ?>
                      <h5 class="border-bottom mt-2">Reply by Admin</h5>
                      <p>
                        <?php echo $row_feedbacks['reply'] ?>
                      </p>
                    <?php } ?>
                  </div>
                </div>
              </div>
            <?php } ?>
          <?php } else { ?>
            <div class="ftco-animate col-12 mt-5 mb-5 pt-5 pb-5">
              <h1 class="text-center text-muted mt-5 mb-5">
                No Datas
              </h1>
            </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </section>
  <hr>

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="js/main.js"></script>

</body>

</html>
<?php
include('include/auth-all.php');
include('include/dbConnect.php');
include('include/helper.php');
$token = $_GET['token'];
$qry = "SELECT * FROM books WHERE token = '$token'";
$qry_book = $db->prepare($qry);
$qry_book->execute();
$row_book = $qry_book->fetch();
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>KITHAB MASTER</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

	<base href="<?php echo $base_url ?>" />
	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">

	<link rel="stylesheet" href="css/aos.css">

	<link rel="stylesheet" href="css/ionicons.min.css">

	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">


	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css<?php echo '?v=' . rand() ?>">
</head>

<body class="goto-here">
	<?php require_once 'include/header.php'; ?>
	<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
		<div class="container">
			<div class="row no-gutters slider-text align-items-center justify-content-center">
				<div class="col-md-9 ftco-animate text-center">
					<h1 class="mb-0 breadd font-weight-bolder text-white"><?php echo strtoupper($row_book['title']) ?></h1>
				</div>
			</div>
		</div>
	</div>
	<section class="ftco-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 mb-5 ftco-animate">
					<a href="<?php echo $row_book['image'] ?>" class="image-popup"><img src="<?php echo $row_book['image'] ?>" class="img-fluid" alt="Colorlib Template"></a>
				</div>
				<div class="col-lg-6 product-details pl-md-5 ftco-animate">
					<h3><?php echo strtoupper($row_book['title']) ?></h3>
					<p class="font-weight-bolder text-dark text-truncate">By <?php echo strtoupper($row_book['author']) ?></p>
					<div class="rating d-flex">
						<p class="text-left">
							PUBLISHED ON <?php echo date_format_local($row_book['created_at'], 'd M Y') ?>
						</p>
					</div>
					<h6 class="d-inline-block border px-4 py-2 bg-dark text-white rounded-pill">YEAR: <?php echo strtoupper($row_book['year']) ?></h6>
					<h6 class="d-inline-block border px-4 py-2 bg-dark text-white rounded-pill">PAGES: <?php echo strtoupper($row_book['pages']) ?></h6>
					<h6 class="d-inline-block border px-4 py-2 bg-dark text-white rounded-pill"><?php echo strtoupper($row_book['category']) ?></h6>
					<p class="price">
						<span class="mr-1 price-dc text-danger font-weight-bolder" style="text-decoration:line-through ;">INR&nbsp;<?php echo number_format($row_book['mrp'], 2) ?></span>
						<span class="price-sale text-success font-weight-bolder">INR&nbsp;<?php echo number_format($row_book['rate'], 2) ?></span>
					</p>

					<p class="text-justify">
						<?php echo ucfirst($row_book['about']) ?>
					</p>
					<?php if ($row_book['created_by'] == $user) {
					?>
						<h5><span>STOCK LEFT: <?php echo $row_book['stock'] ?> NOS</span></h5>
						<?php
						if ($row_book['approved'] == 0) {
							echo '<h5 class="text-danger">WAITING FOR APPROVAL FROM KITHAB MASTER</h5>';
							if ($row_book['edited'] == 1) {
								echo '<h5 class="text-danger">YOU UPDATED THE BOOK DETAILS</h5>';
							}
						} else {
							echo '<h5 class="text-success">APPROVED BY KITHAB MASTER ON ' . date_format_local($row_book['approved_on'], 'd M Y h:i A') . '</h5>';
							if ($row_book['status'] == 0) {
								echo '<h5 class="text-danger">NOT AVAILABLE FOR BUYER. <a href="actions/book-status.php?status=1&token=' . $token . '" class="btn btn-success">PUBLISH</a></h5>';
							} else {
								echo '<h5 class="text-success">AVAILABLE FOR BUYER. <a href="actions/book-status.php?status=0&token=' . $token . '" class="btn btn-danger">UNPUBLISH</a></h5>';
							}
						}
						?>
						<a href="book-edit.php?token=<?php echo $token ?>" class="btn btn-black py-3 px-5 mt-5">EDIT BOOK</a>
					<?php } ?>
					<?php if ($_SESSION['SESS_USER_TYPE'] == 'buyer' && $row_book['stock'] > 0) { ?>
						<p><a href="actions/add-to-cart.php?token=<?php echo $token ?>" class="btn btn-black py-3 px-5 mt-5">ADD TO CART</a></p>
					<?php } ?>
				</div>
			</div>
		</div>
	</section>
	<hr>

	<?php require_once 'include/footer.php'; ?>



	<script src="js/jquery.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>